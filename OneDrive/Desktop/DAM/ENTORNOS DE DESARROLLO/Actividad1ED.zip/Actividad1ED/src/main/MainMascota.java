package main;

import entidad.Mascota;

public class MainMascota {
	public static void main(String[] args) {
		String nombre1 = "Manolo";
		int id1 = 1;
		String color1 = "Blanco";
		
		Mascota m1 = new Mascota(id1, nombre1, color1);
		
		String nombre2 = "Antonio";
		int id2 = 2;
		String color2 = "Negro";
		
		Mascota m2 = new Mascota(id2, nombre2, color2);
		
		System.out.println(m1);
		System.out.println(m2);
	}
}
