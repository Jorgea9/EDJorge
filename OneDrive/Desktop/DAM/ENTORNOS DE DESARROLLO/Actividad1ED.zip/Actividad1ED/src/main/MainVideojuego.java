package main;

import entidad.Videojuego;

public class MainVideojuego {
	public static void main(String[] args) {
		String nombre1 = "Manolo y sus aventuras";
		int id1 = 1;
		String compania1 = "Blanco S.L.";
		
		
		Videojuego v1 = new Videojuego(nombre1, compania1, id1);
		
		String nombre2 = "Antonio y sus aventuras";
		int id2 = 2;
		String compania2 = "Negro S.L";
		
		Videojuego v2 = new Videojuego(nombre2, compania2, id2);
		
		System.out.println(v1);
		System.out.println(v2);
	}
}
