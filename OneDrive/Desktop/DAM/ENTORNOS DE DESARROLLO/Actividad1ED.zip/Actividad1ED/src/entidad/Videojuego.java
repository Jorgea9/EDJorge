package entidad;

public class Videojuego {
	public String nombre;
	public String compa�ia;
	public int id;
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCompa�ia() {
		return compa�ia;
	}
	public void setCompa�ia(String compa�ia) {
		this.compa�ia = compa�ia;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Videojuego [nombre=" + nombre + ", compa�ia=" + compa�ia + ", id=" + id + "]";
	}
	public Videojuego(String nombre, String compa�ia, int id) {
		super();
		this.nombre = nombre;
		this.compa�ia = compa�ia;
		this.id = id;
	}
	
}
